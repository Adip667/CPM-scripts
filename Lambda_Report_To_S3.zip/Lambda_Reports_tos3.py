import urllib3
from botocore.exceptions import ClientError
import boto3
import datetime
from utils import call_rest_endpoint, get_token
import os


def get_report(endpoint, URL_API, tokens, to_date, from_date):
    """
    :param endpoint: the RestAPI endpoint for the report
    :return:
    """
    url = URL_API + 'reports/' + endpoint
    url = url + '?from_time={from_date}&to_time={to_date}'.format(to_date=to_date, from_date=from_date)

    HEADER_ACCEPT = 'text/csv;'
    authorization = 'Bearer {}'.format(tokens[0])
    headers = {'Accept': HEADER_ACCEPT, 'Authorization': authorization}

    response = call_rest_endpoint(url=url, headers=headers, type='get', file=True)

    return response


def GetServernameID(URL_API, tokens):
    """
    :return: the N2WS server ID, to be used for creating the S3 folder name.
    """
    url = URL_API + 'settings/identifier/'

    HEADER_ACCEPT = 'application/json'
    authorization = 'Bearer {}'.format(tokens[0])
    headers = {'Accept': HEADER_ACCEPT, 'Authorization': authorization}

    response = call_rest_endpoint(url=url, headers=headers, type='get')

    return response['cpm_name'] + '_' + response['cpm_uuid']


def upload_report_s3(path, bucketName, reporttype, filename, serverID):
    """
    Upload files to S3
    :param path: path to the file
    :param bucketName: bucket name to upload to
    :param filename: the file to upload
    """

    s3 = boto3.resource('s3')
    try:
        s3.meta.client.upload_file(path, bucketName, serverID + '/' + reporttype + '/' + filename)
    except ClientError as e:
        print(e)


def lambda_handler(event, context):  # do stuff

    host = os.environ['host']
    api_key = os.environ['api_key']
    report_days = int(os.environ['report_days'])  # num of days the report will be generated for
    reports = ('snapshots', 'backups', 'audit')  # the aws report types that we are going to download from N2WS
    bucket_name = 'report-archive-cpm'

    URL_API = 'https://{}/api/'.format(host)  # updating the base URL with the provided Host
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    tokens = get_token(URL_API, api_key)  # calling function to generate access token from the provided API key
    serverID = GetServernameID(URL_API, tokens)  # getting server id, to use in folder name in the S3 bucket.

    from_date = (datetime.datetime.now() - datetime.timedelta(days=report_days)).strftime('%Y-%m-%dT%H:%M:%SZ')  # from date based on report_days
    to_date = (datetime.datetime.now()).strftime('%Y-%m-%dT%H:%M:%SZ')  # setting today date

    for reportType in reports:
        response = get_report(reportType, URL_API, tokens, to_date, from_date)  # response will contain filename
        upload_report_s3("/tmp/" + response, bucket_name, reportType, response, serverID)  # upload the report to the S3 bucket

